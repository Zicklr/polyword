package wordgraphic.bones;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;


/***
 * 
 * @author Zicklr
 *@version 2013-03-16
 */
public class Graphe {
	
	// liste de tous les sommets de notre graphe
	private ArrayList<Sommet> noeuds;
    
    public Graphe(){
    	noeuds =  new ArrayList<Sommet>(500000);
    	List<? extends Sommet> tmp = Collections.nCopies(500000, new Sommet(0,null,0,0));
    	noeuds.addAll(tmp);
    	
    }
	/**
	 * Cr��e le graphe depuis un autre graphe existant
	 * 
	 * @param 	graph	Le graphe est une clone du graphe pr�c�dent
	 * 
	 * @author	Zicklr
	 */
	public Graphe(Graphe g) {
		noeuds = g.noeuds;
	}
	
	/**
	 * @param	arete	
	 * @throws	NullPointerException	
	 * 
	 * @author	Abou-Aichi Mathieu
	 * @see		Arete
	 */
	public void addArete(Arete t) throws NullPointerException {
		Objects.requireNonNull(t);
		noeuds.get(t.getSource()).addAreteIncidente(t);
		noeuds.get(t.getDestination()).addAreteIncidente(t);
	}
	
	public void addSommet(Sommet newSom) {
		if(newSom!=null)
			noeuds.set(newSom.getId(), newSom);
	}
	public List<Sommet> getSommets() {
		return noeuds;
	}
	public Sommet selectById(int id) {
		return noeuds.get(id);
	}


}
