package wordgraphic.bones.parsor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import wordgraphic.bones.Arete;
import wordgraphic.bones.Sommet;
import wordgraphic.bones.parsor.gestionnaireParsing.Handler;


	public class DataRobot implements Handler {
		private final Pattern nodePattern, relationPattern;
		DataRobot() {
			nodePattern = Pattern.compile("eid=(\\d+)[|]n=[\"](.*)[\"][|]t=1[|]w=(\\d+)(|[|]nf=[\"](.*)[\"])");
			relationPattern = Pattern.compile("rid=(\\d+)[|]n1=(\\d+)[|]n2=(\\d+)[|]t=(\\d+)[|]w=(\\d+)");
		}
		
		public Sommet semiNodeMet(String data) {
			Pattern pattern = Pattern.compile(".*n=[\"](.*)[\"][|]w=(\\d+)");
			Matcher matcher = pattern.matcher(data);
			return new Sommet(0, matcher.group(1), 1, Integer.parseInt(matcher.group(2)));
		}
		
		@Override
		public Sommet noeudParse(String d) {
			Matcher matcher = nodePattern.matcher(d);
			if(matcher.matches() && !"0".equals(matcher.group(1))) {
				return new Sommet(Integer.parseInt(matcher.group(1)), matcher.group(2), 1, Integer.parseInt(matcher.group(3)));
			}
			return null;
		}
		
		@Override
		public Arete relationParsee(String d) {
			Matcher matcher = relationPattern.matcher(d);
			if(matcher.matches()) {
				return new Arete(Integer.parseInt(matcher.group(1)), Integer.parseInt(matcher.group(2)), Integer.parseInt(matcher.group(3)), Integer.parseInt(matcher.group(4)));
			}
			return null;
		}

	
	}


