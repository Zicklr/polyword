package wordgraphic.bones.parsor;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import wordgraphic.bones.Arete;
import wordgraphic.bones.Graphe;
import wordgraphic.bones.Sommet;

public class DataParsor implements AutoCloseable {
	private Graphe g;
	private final Scanner s;
	private final DataRobot parseur;
	private int nbSommetsMax;
	
	public DataParsor(Path file) throws IOException {
		g = new Graphe();
		this.s = new Scanner(file);
		parseur = new DataRobot(/*graph.getNodes()*/);
	}
	public DataParsor(Path file, DataRobot parseur) throws IOException {
		this.s = new Scanner(file);
		this.parseur = (DataRobot)parseur;
	}
	public Graphe parse() throws IOException {
		return parseEverything(-1);
	}

	public Graphe parse(int max) throws IOException {
		if((max >= findNumberOfNodes()) || (max == 0)) {
			return parseEverything(-1);
		}
		return parseEverything(max);
	}

	private int findNumberOfNodes() {
		Pattern pattern = Pattern.compile(".*MAX NODE ID = (\\d+).*");
		while(s.hasNext()) {
			String line = s.nextLine();
			Matcher matcher = pattern.matcher(line);
			if(matcher.matches()) {
				int nbSommetsMax = Integer.parseInt(matcher.group(1));;
				return nbSommetsMax;
			}
		}
		return 0;
	}

	private Graphe parseEverything(int max) throws IOException {
		g = new Graphe();
		System.out.println("Chargement des sommets ...");
		if(max != -1) {
			parseSommetslambda(max);
		} else {
			parseSommets();
			System.out.println("Poupou");
		}
		System.out.println("Chargement des aretes...");
		parseAretes();
		return g;
	}
	private void parseSommetslambda(int max) {
		Random randomizer = new Random();
		while(s.hasNext() && max != 0) {
			String line = s.nextLine();
			if(line.matches("^eid.*t=1.*") && (randomizer.nextInt(6) < 3)) {
				g.addSommet(parseur.noeudParse(line));
			} else if(line.matches(".*RELATIONS$")) {
				return;
			}
		}
	}

	private void parseSommets() throws IOException {
		int i = 0;
		Sommet newNode=new Sommet(0,"",0,0);	
		while(s.hasNext()) {
			String line = s.nextLine();
			if(line.matches("^eid.*t=1.*")) {
					newNode = parseur.noeudParse(line);
					if(newNode!=null){
						g.addSommet(newNode);
						i++;
						System.out.println("Sommet ajoute : "+i);
					}
			} else if(line.matches(".*RELATIONS$")) {
				return;
			}
		}
	}

	private void parseAretes() throws IOException {
		int i = 1;
		Arete newArete=new Arete(0,0,0,0);
		while(s.hasNext()) {
			String line = s.nextLine();
			if(line.matches("^rid.*")) {
				newArete = parseur.relationParsee(line);	
				 if(newArete.getId()!=0){
					 i++;
					 System.out.println("Arete ajoutee : "+i);
				 }
					
				}
			}
		}
	
	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		s.close();
	}
	public int getNbSommetsMax() {
		return nbSommetsMax;
	}
	public void setNbSommetsMax(int nbSommetsMax) {
		this.nbSommetsMax = nbSommetsMax;
	}

	
	
}
