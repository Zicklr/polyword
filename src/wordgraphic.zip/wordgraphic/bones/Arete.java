package wordgraphic.bones;

public class Arete {
	
    private final int poids;
    private final int origineId;
    private final int destinationId;
    private final int id;
    
    /**
     * Full constructor
     */

    public Arete(int poids, int origineId, int destinationId, int id) {
		this.poids = poids;
		this.origineId = origineId;
		this.destinationId = destinationId;
		this.id = id;
	}



	/**
     * Return the cost of this edge
     */
    public int getPoids()
    {
        return poids;
    }

    /**
     * Return the source vertex for this edge
     * @return
     */
    public int getSource()
    {
        return origineId;
    }


    /**
     * Return the destination vertex of this edge
     */
    public int getDestination()
    {
        return destinationId;
    }
    /**
     * Return the string representing this edge
     */
    public String toString()
    {
        return "Arete( source:"+origineId+
               " dest:"+destinationId+" poids:"+poids+")";
    }

    /**
     * @Override default equals method
     */
	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		Arete o = (Arete) obj;
		return (id == o.id);
	}

	public int getId() {
		return id;
	}

}
