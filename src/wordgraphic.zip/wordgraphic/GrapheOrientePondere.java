package wordgraphic;
/***
 * 
 * @author Zicklr
 *@version 2013-03-16
 */
public class GrapheOrientePondere {
	
	// list of all the vertex in our graph
    private Liste<Sommet> sommets;
    // list of all edges in our graph
    private Liste<Arete> aretes;
    
    public GrapheOrientePondere(){
    	sommets =  new Liste<Sommet>();
    	aretes = new Liste<Arete>();
    }

	public Liste<Sommet> getSommets() {
		return sommets;
	}

	public void setSommets(Liste<Sommet> sommets) {
		this.sommets = sommets;
	}

	public Liste<Arete> getAretes() {
		return aretes;
	}

	public void setAretes(Liste<Arete> aretes) {
		this.aretes = aretes;
	}

}
